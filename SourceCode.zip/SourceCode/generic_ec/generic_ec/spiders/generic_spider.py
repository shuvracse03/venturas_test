import scrapy
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

class GenericCrawler(CrawlSpider):
    name = 'generic_crawler'
    allowed_domains = ['site1.com', 'site2.com', 'site3.com']
    start_urls = ['https://site1.com/', 'https://site2.com/', 'https://site3.com/']
    rules = [
        Rule(LinkExtractor(), callback='parse_item', follow=True)
    ]

    def parse_item(self, response):
        site_url = response.url.split('/')[2]  # Extracting the domain from URL
        if site_url == 'site1.com':
            self.parse_site1(response)
        elif site_url == 'site2.com':
            self.parse_site2(response)
        elif site_url == 'site3.com':
            self.parse_site3(response)

    def parse_site1(self, response):
        # Parsing logic for site1.com
        title = response.css('h1::text').get()
        page_url = response.url
        self.save_data(title, page_url, 'site1.com')

    def parse_site2(self, response):
        # Parsing logic for site2.com
        title = response.css('h2::text').get()
        page_url = response.url
        self.save_data(title, page_url, 'site2.com')

    def parse_site3(self, response):
        # Parsing logic for site3.com
        title = response.css('h3::text').get()
        page_url = response.url
        self.save_data(title, page_url, 'site3.com')

    def save_data(self, title, url, site_url):
        # Placeholder for saving data to a database, file, or any other destination
        print(f"Site URL: {site_url}\nTitle: {title}\nURL: {url}\n")
